#!/bin/sh
# Run this to generate all the initial makefiles, etc.
autoreconf -i -v && echo Now run ./configure and make
